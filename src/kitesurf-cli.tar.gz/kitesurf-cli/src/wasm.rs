use wasmtime::{Config, Engine, Instance, Memory, Module, OptLevel, Store, TypedFunc};

pub struct Raster {
    store: Store<()>,
    memory: Memory,
    alloc: TypedFunc<u32, u32>,
    free: TypedFunc<(u32, u32), ()>,
    call: TypedFunc<(u32, u32, u32), u64>,
}

impl Raster {
    pub fn new(bytes: &[u8]) -> Result<Self, Box<dyn std::error::Error>> {
        // Keep replay optimized; Cargo's parallel-compilation feature reduces
        // the cost of compiling the downloaded rasterizer on every launch.
        let engine = Engine::new(Config::new().cranelift_opt_level(OptLevel::Speed))?;
        let module = Module::from_binary(&engine, bytes)?;
        let mut store = Store::new(&engine, ());
        // This is the JS-free build; imports would mean the wrong artifact was served.
        let instance = Instance::new(&mut store, &module, &[])?;
        Ok(Self {
            memory: instance
                .get_memory(&mut store, "memory")
                .ok_or("missing memory")?,
            alloc: instance.get_typed_func(&mut store, "ks_alloc")?,
            free: instance.get_typed_func(&mut store, "ks_free")?,
            call: instance.get_typed_func(&mut store, "ks_call")?,
            store,
        })
    }

    pub fn run(&mut self, op: u32, input: &[u8]) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        let input_len = u32::try_from(input.len())?;
        let input_ptr = self.alloc.call(&mut self.store, input_len)?;
        if input_len > 0 && input_ptr == 0 {
            return Err("guest allocation failed".into());
        }
        if let Err(error) = self.memory.write(&mut self.store, input_ptr as usize, input) {
            self.free.call(&mut self.store, (input_ptr, input_len))?;
            return Err(error.into());
        }
        let call_result = self.call.call(&mut self.store, (op, input_ptr, input_len));
        self.free.call(&mut self.store, (input_ptr, input_len))?;
        let packed_output = call_result?;
        let output_ptr = packed_output as u32;
        let output_len = (packed_output >> 32) as u32;
        let mut output = vec![0; output_len as usize];
        if output_len > 0 {
            let read = self.memory.read(&self.store, output_ptr as usize, &mut output);
            self.free.call(&mut self.store, (output_ptr, output_len))?;
            read?;
        }
        Ok(output)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn downloaded_module_runs_without_js_imports() {
        let path = concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../engine/public/rbi/scene_host.wasm"
        );
        let bytes = std::fs::read(path).expect("run pnpm run build:scene-host:raw first");
        let mut raster = Raster::new(&bytes).unwrap();
        assert_eq!(raster.run(2, &[]).unwrap(), [0, 0, 0, 0]);

        // An image that the server cannot fill must be retired.
        let mut batch = vec![1, 0, 0, 0, 2];
        batch.extend_from_slice(&42u64.to_le_bytes());
        batch.extend_from_slice(&17u32.to_le_bytes());
        batch.extend_from_slice(&16u32.to_le_bytes());
        batch.extend_from_slice(&16u32.to_le_bytes());
        batch.push(3);
        batch.extend_from_slice(&16u32.to_le_bytes());
        batch.extend_from_slice(&16u32.to_le_bytes());
        raster.run(1, &batch).unwrap();
        assert_eq!(raster.run(8, &[]).unwrap(), br#"["42"]"#);
        raster.run(9, b"42").unwrap();
        assert_eq!(raster.run(8, &[]).unwrap(), b"[]");
    }

    #[test]
    fn cropped_partial_returns_only_the_requested_png_rectangle() {
        let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/../engine/public/rbi/");
        let bytes = std::fs::read(format!("{dir}scene_host.wasm")).unwrap();
        let manifest: serde_json::Value = serde_json::from_slice(
            &std::fs::read(format!("{dir}scene_host.json")).unwrap(),
        ).unwrap();
        let mut scene = b"KSC0".to_vec();
        scene.extend_from_slice(&(manifest["wireVersion"].as_u64().unwrap() as u32).to_le_bytes());
        for value in [4u32, 4, 0, 0, 0, 0, 0, 4] {
            scene.extend_from_slice(&value.to_le_bytes());
        }
        let mut raster = Raster::new(&bytes).unwrap();
        let full = raster.run(10, &scene).unwrap();
        assert_eq!(&full[..8], b"\x89PNG\r\n\x1a\n");
        assert_eq!(&full[16..24], &[0, 0, 0, 4, 0, 0, 0, 4]);
        let raw = raster.run(14, &scene).unwrap();
        assert_eq!(&raw[..8], &[4, 0, 0, 0, 4, 0, 0, 0]);
        assert_eq!(raw.len(), 8 + 4 * 4 * 4);

        let mut cropped = Vec::new();
        for value in [1u32, 1, 2, 2] { cropped.extend_from_slice(&value.to_le_bytes()); }
        cropped.extend_from_slice(&scene);
        let png = raster.run(11, &cropped).unwrap();
        assert_eq!(&png[..8], b"\x89PNG\r\n\x1a\n");
        assert_eq!(&png[16..24], &[0, 0, 0, 2, 0, 0, 0, 2]);

        let decode = |bytes: &[u8]| {
            let mut reader = png::Decoder::new(std::io::Cursor::new(bytes))
                .read_info().unwrap();
            let mut pixels = vec![0; reader.output_buffer_size().unwrap()];
            let info = reader.next_frame(&mut pixels).unwrap();
            pixels.truncate(info.buffer_size());
            pixels
        };
        let full_pixels = decode(&full);
        assert_eq!(&raw[8..], full_pixels);
        let cropped_pixels = decode(&png);
        for row in 0..2 {
            let start = ((row + 1) * 4 + 1) * 4;
            assert_eq!(&cropped_pixels[row * 8..row * 8 + 8], &full_pixels[start..start + 8]);
        }
    }
}
